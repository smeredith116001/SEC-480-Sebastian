function bClone() { 
    Clear-Host
    Write-Host "Options"
    Write-Host "[0] Main Menu"
    $selectedVM = $null
        $vms = Get-VM | Where-Object { $_.Name -notlike '*base'} #Get-VM -Location $config.folder 
        $index = 1
        foreach($vm in $vms) {
            Write-Host  "[$index] $($vm.name)"
            $index+=1
        }
        Write-Host ""
        $vmInput = Read-Host 'Which index number [x] do you wish to use to create a Base Clone?'
        # could make check a function
        if ($vmInput -match '^\d+$') {
            $key = [int]$vmInput - 1
            if ($key -lt 0) {
                Clear-Host
            }elseif($key -ge $vms.Count){
                Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID to create a Base Clone"
                Start-Sleep -Seconds 1.5
                bClone #-folder $config.folder
            }else {
                $selectedVM = $vms[$key]
                Write-Host ""
                Write-Host "You picked $($selectedVM.name)."
                $confirm = Read-Host -Prompt "Are you sure you want to clone the selected virtual machine (Y/N)? "
                if ($confirm -eq "Y" -or $confirm -eq "y" -or $confirm -eq "yes"-or $confirm -eq "Yes") {
                    Clear-Host
                    createLinkedClone $selectedVM
                } else {
                  Clear-Host
                  Write-Host "Cloning cancelled. Please select a valid Index ID to create a Base Clone"
                  bClone #-folder $config.folder
                }
            }
        }else{
            Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID to create a Base Clone"
            Start-Sleep -Seconds 1.5
            bClone
        }
}

# Used to create Full Clones - Will list ONLY VMs in BASE-VM Folder
function fClone() {
    $config = (Get-Content -Raw -Path "/home/sebastian/Documents/480.json" | ConvertFrom-Json)
    Clear-Host
    Write-Host "Options"
    Write-Host "[0] Main Menu"
    $selectedVM = $null
        $vms = Get-VM -Location $config.folder
        $index = 1
        foreach($vm in $vms) {
            Write-Host  "[$index] $($vm.name)"
            $index+=1
        }
        Write-Host ""
        $vmInput = Read-Host 'Which index number [x] do you wish to use to create a Full Clone?'
        # could make check a function
        if ($vmInput -match '^\d+$') {
            $key = [int]$vmInput - 1
            if ($key -lt 0) {
                Clear-Host
                intMenu
            }elseif($key -ge $vms.Count){
                Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID to create a Full Clone"
                Start-Sleep -Seconds 1.5
                fClone -folder $config.folder
            }else {
                $selectedVM = $vms[$key]
                Write-Host ""
                Write-Host "You picked $($selectedVM.name)."
                $confirm = Read-Host -Prompt "Are you sure you want to clone the selected virtual machine (Y/N)? "
                if ($confirm -eq "Y" -or $confirm -eq "y" -or $confirm -eq "yes"-or $confirm -eq "Yes") {
                    Clear-Host
                    createLinkedClone $selectedVM
                } else {
                  Clear-Host
                  Write-Host "Cloning cancelled. Please select a valid Index ID to create a Full Clone"
                  fClone #-folder $config.folder
                }
            }
        }else{
            Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID to create a Full Clone"
            Start-Sleep -Seconds 1.5
            fClone
        }
}

# Used to create linked Clones - Will list ALL VMs
function linkedClone1() {
    $config = (Get-Content -Raw -Path "/home/sebastian/Documents/480.json" | ConvertFrom-Json)
    Clear-Host
    Write-Host "Options"
    Write-Host "[0] Main Menu"
    $selectedVM = $null
        $vms = Get-VM #-Location $config.folder
        $index = 1
        foreach($vm in $vms) {
            Write-Host  "[$index] $($vm.name)"
            $index+=1
        }
        Write-Host ""
        $vmInput = Read-Host 'Which index number [x] do you wish to use to create a Linked Clone?'
        # could make check a function
        if ($vmInput -match '^\d+$') {
            $key = [int]$vmInput - 1
            if ($key -lt 0) {
                Clear-Host
                intMenu
            }elseif($key -ge $vms.Count){
                Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID to create a Full Clone"
                Start-Sleep -Seconds 1.5
                linkedClone1 #-folder $config.folder
            }else {
                $selectedVM = $vms[$key]
                Write-Host ""
                Write-Host "You picked $($selectedVM.name)."
                $confirm = Read-Host -Prompt "Are you sure you want to clone the selected virtual machine (Y/N)? "
                if ($confirm -eq "Y" -or $confirm -eq "y" -or $confirm -eq "yes"-or $confirm -eq "Yes") {
                    Clear-Host
                    linkedClone $selectedVM
                } else {
                  Clear-Host
                  Write-Host "Cloning cancelled. Please select a valid Index ID to create a Full Clone"
                  linkedClone1 #-folder $config.folder
                }
            }
        }else{
            Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID to create a Full Clone"
            Start-Sleep -Seconds 1.5
            fClone
        }
}

# Creates linked Clones - gets deleted
function createLinkedClone($selectedVM) {
    $config = (Get-Content -Raw -Path "/home/sebastian/Documents/480.json" | ConvertFrom-Json)
    $snapshot = Get-Snapshot -VM $selectedVM.Name -Name "Base" 
    $linkedClone = "{0}.linked" -f $selectedVM.Name
    $linkedVM = New-VM -LinkedClone -Name $linkedClone -VM $selectedVM.Name -ReferenceSnapshot $snapshot -VMHost $config.esxi_host -Datastore $config.default_datastore 
    $linkedVM | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $config.default_network -Confirm:$false
    Write-Host $linkedVM
    Write-Host $selectedVM
    newVM $linkedVM
  }

# Creates linked Clone - does not get deleted
function linkedClone($selectedVM) {
    $config = (Get-Content -Raw -Path "/home/sebastian/Documents/480.json" | ConvertFrom-Json)
    $snapshot = Get-Snapshot -VM $selectedVM.Name -Name "Base"
    $inputName = Read-Host "Enter a name for the linked VM" 
    $linkedClone = $inputName -f $selectedVM.Name
    $linkedVM = New-VM -LinkedClone -Name $linkedClone -VM $selectedVM.Name -ReferenceSnapshot $snapshot -VMHost $config.esxi_host -Datastore $config.default_datastore 
    $linkedVM | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $config.default_network -Confirm:$false
    Write-Host ""
    Write-Host "$linkedVM has been created"
    finishCheck
}

# Uses linkedVM to create a new VM  
function newVM($linkedVM) {
    $config = (Get-Content -Raw -Path "/home/sebastian/Documents/480.json" | ConvertFrom-Json)
    Clear-Host
    $nameVM = Read-Host -Prompt "Enter the name of the new VM"
    Write-Host ""
    Write-Host "Creating $nameVM and taking initial snapshot"
    Write-Host ""
    $newVM = New-VM -Name $nameVM -VM $linkedVM -VMHost $config.esxi_host -Datastore $config.default_datastore #-Folder $config.folder
    $newVM = $newVM | New-Snapshot -Name "Base" #-Confirm:$false -Description:$false
    Write-Host ""
    Write-Host -ForegroundColor "Green" "$nameVM has been created with a snapshot named 'Based'"
    cleanUp $linkedVM
    }

# Removes linkedVM from instance
function cleanUp($linkedVM) {
    Write-Host ""
    #Write-Host "Deleting $linkedVM"
    $linkedVM | Remove-VM -DeletePermanently -Confirm:$false
    Write-Host "Deleted $linkedVM"
    finishCheck
    }

function 480Connect() {
    $config_path= "/home/sebastian/Documents/480.json"
    $conn = $global:DefaultVIServer
    if ($conn){
        $msg = "Already Connected to: {0}" -f $conn
        Write-Host -ForegroundColor Green $msg 
        Write-Host ""
    }else {
        Write-Host "Login to vCenter"
        $conn = Connect-VIServer -Server "vcenter.sebastian.local"
    }

}
function vmMenu([string[]] $folder) {
    Write-Host "Select Option"
    Write-Host "[0] Main Menu"
    Write-Host "[1] Create Clone" 
    Write-Host "[2] Delete VM"
    Write-Host "[3] Retreive VM "
    Write-Host "[4] Power Options"
    Write-Host "[5] Edit a VM"
    Write-Host ""
    $menuInput = Read-Host 'Which index number [x] do you wish to pick?'
    if ($menuInput -eq "1"){
        cMenu
    }elseif($menuInput -eq '2'){
        selectDelete
    }elseif($menuInput -eq '0'){
        Clear-Host
        mMenu
    }elseif($menuInput -eq '3'){
        Clear-Host
        vmNetworking
    }elseif($menuInput -eq '4'){
        Clear-Host
        powerMenu
    }elseif($menuInput -eq '5'){
        Clear-Host
        editMenu
    }else{
        Write-Host -ForegroundColor "Red" "Invalid Option. Please Select a valid index number [x]."
        Start-Sleep -Seconds 1.5
        Clear-Host
        vmMenu
    }

}