function networkMenu(){
    Write-Host "Select Option"
    Write-Host "[0] Main Menu"
    Write-Host "[1] List Virtual Switches " 
    Write-Host "[2] Create Virtual Switch"
    Write-Host "[3] Create Virtual Portgroup"
    Write-Host "[4] Delete Virtual Switch"
    Write-Host "[5] Delete Virtual Portgroup"
    Write-Host ""
    $menuInput = Read-Host 'Which index number [x] do you wish to pick?'
    if ($menuInput -eq "0"){    
        Clear-Host
        intMenu
    }elseif($menuInput -eq '1'){
        $listVS = Get-VirtualSwitch
        $listPG = Get-VirtualPortGroup
        Write-Host ""
        Write-Host "Virtual Switches:"
        foreach ($item in $listVS) {Write-Host $item } 
        Write-Host ""
        Write-Host "Port Groups:"
        foreach ($item in $listPG) {Write-Host $item }
        Write-Host
        networkMenu
    }elseif($menuInput -eq '2'){
        Clear-Host
        newVSwitch
    }elseif($menuInput -eq '3'){
        Clear-Host
        newVPort
    }elseif($menuInput -eq '4'){
        Clear-Host
        delVSwitch
    }elseif($menuInput -eq '5'){
        Clear-Host
        delVPort
    }else{
        Write-Host  "Please Select a valid index number [x]."
        Start-Sleep -Seconds 1.5
        Clear-Host
        networkMenu
    }
}
# Creates New Virtual Switch 
function newVSwitch(){
    $config = (Get-Content -Raw -Path "/home/sebastian/Documents/480.json" | ConvertFrom-Json)
    Write-Host ""
    $readvSwitch = Read-Host "Provide a name for the new Virtual Switch"
    $vSwitch = New-VirtualSwitch -VMHost $config.esxi_host -Name $readvSwitch
    Write-Host ""
    Write-Host "$vSwitch has been successfully created"
    $userInput = Read-Host "Would you like to create a new Port Group (Y/N)"
    if ($userInput -eq "Y" -or $userInput -eq "y" -or $userInput -eq "yes"-or $userInput -eq "Yes") {
        newVPort $vSwitch
    } else {
        finishCheck
} 
}

# Creates New Virtual Portgroup
function newVPort($vSwitch){
    
    Write-Host ""
    $readPort = Read-Host "Provide a name for the new Portgroup"
    if ($vSwitch -ne $null){
        $portGroup = New-VirtualPortGroup -VirtualSwitch $vSwitch -Name $readPort
        Write-Host ""
        Write-Host "$portGroup has been successfully created"
        Write-Host ""
        finishCheck
    }elseif ($vSwitch -eq $null){
        $listVS = Get-VirtualSwitch | Where-Object { $_.Name}
        $index=1
        Write-Host "[0] Go Back"
        foreach ($item in $listVS){
            Write-Host "[$index] $item"
            $index+=1
        }
        Write-Host ""
            $vmInput = Read-Host 'Which index number [x] do you wish to delete?'
            if ($vmInput -match '^\d+$') {
                $key = [int]$vmInput - 1
                if ($key -lt 0) {
                    Clear-Host
                    networkMenu
                }elseif($key -ge $listVS.Count){
                    Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID"
                    Start-Sleep -Seconds 1.5
                    newVPort
                } else {
                    $selected = $listVS[$key]
                    Write-Host ""
                    $confirm = Read-Host -Prompt "Are you sure you want to use the $selected virtual switch to create $readPort (Y/N)? "
                if ($confirm -eq "Y" -or $confirm -eq "y" -or $confirm -eq "yes"-or $confirm -eq "Yes") {
                    Clear-Host
                    $portGroup = New-VirtualPortGroup -VirtualSwitch $selected -Name $readPort
                    Write-Host ""
                    Write-Host "$portGroup has been successfully created"
                    Write-Host ""
                    finishCheck
                } else {
                  Clear-Host
                  Write-Host "Creation cancelled."
                  newVPort 
                }
            }
        }else{
            Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID"
            Start-Sleep -Seconds 1.5
            delVSwitch
        }
        
    }else{
        finishCheck
    }
    
    
}

# Deletes Virtual Switch 
function delVSwitch(){
    Write-Host ""
    Write-Host "Virtual Switches:"
    Write-Host "[0] Go back"
    $listVS = Get-VirtualSwitch | Where-Object { $_.Name}
    $index=1
    foreach ($item in $listVS){
        Write-Host "[$index] $item"
        $index+=1
    }
    Write-Host ""
        $vmInput = Read-Host 'Which index number [x] do you wish to delete?'
        if ($vmInput -match '^\d+$') {
            $key = [int]$vmInput - 1
            if ($key -lt 0) {
                Clear-Host
                networkMenu
            }elseif($key -ge $listVS.Count){
                Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID"
                Start-Sleep -Seconds 1.5
                delVSwitch
            } else {
                $selected = $listVS[$key]
                Write-Host ""
                Write-Host "You picked $($selected)."
                $confirm = Read-Host -Prompt "Are you sure you want to delete the selected virtual switch and associate portgroup (Y/N)? "
                if ($confirm -eq "Y" -or $confirm -eq "y" -or $confirm -eq "yes"-or $confirm -eq "Yes") {
                    Clear-Host
                    Remove-VirtualSwitch -VirtualSwitch $selected -Confirm:$false
                    Write-Host "$selected has been deleted"
                    finishCheck
                } else {
                  Clear-Host
                  Write-Host "Delete cancelled."
                  delVSwitch 
                }
            }
        }else{
            Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID"
            Start-Sleep -Seconds 1.5
            delVSwitch
        }
    
}

# Deletes Virtual Portgroup
function delVPort(){
    Write-Host ""
    Write-Host "Virtual Portgroups:"
    Write-Host "[0] Go back"
    $listVP = Get-VirtualPortGroup | Where-Object { $_.Name}
    $index+=1
    foreach ($item in $listVP){
        Write-Host "[$index] $item"
        $index+=1
    } 
    Write-Host ""
    $vmInput = Read-Host 'Which index number [x] do you wish to delete?'
    if ($vmInput -match '^\d+$') {
        $key = [int]$vmInput - 1
        if ($key -lt 0) {
            Clear-Host
            networkMenu
        }elseif($key -ge $listVP.Count){
            Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID"
            Start-Sleep -Seconds 1.5
            delVPort
        } else {
            $selected = $listVP[$key]
            Write-Host ""
            Write-Host "You picked $($selected)."
            $confirm = Read-Host -Prompt "Are you sure you want to delete the selected virtual portgroup (Y/N)? "
            if ($confirm -eq "Y" -or $confirm -eq "y" -or $confirm -eq "yes"-or $confirm -eq "Yes") {
                Clear-Host
                Remove-VirtualPortGroup -VirtualPortGroup $selected -Confirm:$false
                Write-Host "$selected has been deleted"
                finishCheck
            } else {
              Clear-Host
              Write-Host "Delete cancelled."
              delVPort 
            }
        }
    }else{
        Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID"
        Start-Sleep -Seconds 1.5
        delVPort
    }

}

function vmNetworking() {
    $selectedVM = $null
        $vms = Get-VM #-Location $config.folder
        $index = 1
        Write-Host "[0] Go Back"
        foreach($vm in $vms) {
            Write-Host  "[$index] $($vm.name)"
            $index+=1
        }
        Write-Host ""
        $vmInput = Read-Host "Which index number [x] do you wish to use to retireve the VM's network information?"
        if ($vmInput -match '^\d+$') {
            $key = [int]$vmInput - 1
            if ($key -lt 0) {
                Clear-Host
                vmMenu
            }elseif($key -ge $vms.Count){
                Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID to create a Full Clone"
                Start-Sleep -Seconds 1.5
                vmNetworking
            }else {
                $selectedVM = $vms[$key]
                $net2 = Get-VM -name $selectedVM | Select Name, @{N="IP Address";E={@($_.guest.IPAddress[0])}}
                $net = Get-VM -name $selectedVM | Get-NetworkAdapter
                Write-Host ""
                Write-Host "VM Name: "$net2.Name
                Write-Host "Network: "$net.NetworkName
                Write-Host "IP Address: "$net2.'IP Address'
                Write-Host "Mac Address: "$net.MacAddress
                Write-Host ""
                finishCheck
            }
        }else{
            Write-Host -ForegroundColor "Red" "Invalid Index ID. Please select a valid Index ID"
            Start-Sleep -Seconds 1.5
            vmNetworking
        }
}